from ..stbt_nursery.control_soak import soak_remote_control


def test_soak_remote_control():
    soak_remote_control(mask="Home - Clock Mask.png")
