import stbt

from tests.stbt_nursery.mask import mask_out
from tests.stbt_nursery.navigation import EndOfList, VerticalMenuMixin


class HomeMenu(stbt.FrameObject, VerticalMenuMixin):
    PIP = stbt.Region(57, 50, 269, 153)
    CLOCK_AND_WEATHER = stbt.Region(716, 25, 502, 77)

    @staticmethod
    def launch():
        page = HomeMenu()
        if page:
            return page
        assert stbt.press_and_wait(
            'KEY_HOME',
            mask=mask_out(HomeMenu.PIP) & mask_out(HomeMenu.CLOCK_AND_WEATHER))
        page = HomeMenu()
        assert page, "Failed to launch HomeMenu with KEY_HOME"
        return page

    @property
    def is_visible(self):
        return "LIVE TV" == stbt.ocr(
            frame=self._frame, region=stbt.Region(110, 266, 75, 21),
            mode=stbt.OcrMode.SINGLE_LINE)

    @property
    def grid(self):
        return stbt.Grid(stbt.Region(0, 254, 260, 240), cols=1, rows=5)

    @property
    def selection(self):
        m = stbt.match(
            "selection.png", frame=self._frame,
            region=self.grid.region.replace(width=63))
        if m:
            return self.grid.get(region=m.region)

    @property
    def selection_text(self):
        if self.selection:
            return stbt.ocr(
                frame=self._frame, region=self.selection.region.replace(x=110),
                text_color=(57, 0, 0))

    def move_one(self, key):
        if stbt.press_and_wait(
            key,
            mask=mask_out(HomeMenu.PIP) & mask_out(HomeMenu.CLOCK_AND_WEATHER)):
            return self.refresh()
        else:
            raise EndOfList()

    def navigate_to(self, selection_text):  # pylint: disable=arguments-differ
        page = self
        for _ in range(10):
            if page.selection:
                break
            page = page.move_one('KEY_LEFT')
        return super(HomeMenu, page).navigate_to(selection_text=selection_text)
