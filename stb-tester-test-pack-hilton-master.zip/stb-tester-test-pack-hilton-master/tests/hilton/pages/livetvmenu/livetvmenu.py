import stbt

from tests.stbt_nursery.playback import wait_for_content_start


class LiveTvMenu(stbt.FrameObject):
    @staticmethod
    def launch():
        page = LiveTvMenu()
        if page:
            return page
        else:
            from ..homemenu import HomeMenu
            page = HomeMenu.launch()
            page.navigate_to(selection_text="LIVE TV")
            page = LiveTvMenu()
            assert page
            return page

    @property
    def is_visible(self):
        return stbt.ocr(
            frame=self._frame, region=stbt.Region(446, 258, 728, 41)) == (
                "Enjoy a great selection of channels")

    @property
    def grid(self):
        return stbt.Grid(stbt.Region(448, 339, 772, 332), cols=4, rows=2)

    @property
    def home_menu(self):
        from ..homemenu import HomeMenu
        return HomeMenu(frame=self._frame)

    @property
    def selection(self):
        if self.home_menu.selection:
            return self.home_menu.selection.region
        m = stbt.match("selection.png", region=self.grid.region.dilate(5),
                       frame=self._frame)
        if m:
            return self.grid.get(region=m.region).region

    @property
    def selection_text(self):
        if self.home_menu.selection:
            return None
        text_region = self.selection.extend(y=123).replace(height=24)
        return stbt.ocr(frame=self._frame, region=text_region,
                        mode=stbt.OcrMode.SINGLE_LINE)

    def launch_tv(self):
        page = self
        for _ in range(3):
            if page.selection_text and page.selection_text != "GUIDE":
                break
            assert stbt.press_and_wait("KEY_RIGHT", region=self.grid.region)
            page = page.refresh()
        else:
            assert False, "Failed to find TV channel tile"
        keypress = stbt.press('KEY_OK')
        return wait_for_content_start(keypress)
