import stbt

from tests.stbt_nursery.navigation import Movable


class StreamingMenu(stbt.FrameObject, Movable):
    @staticmethod
    def launch():
        page = StreamingMenu()
        if page:
            return page
        else:
            from ..homemenu import HomeMenu
            page = HomeMenu.launch()
            page.navigate_to(selection_text="STREAMING")
            page = StreamingMenu()
            assert page
            return page

    @property
    def is_visible(self):
        return stbt.ocr(
            frame=self._frame, region=stbt.Region(446, 258, 728, 41)) == (
                "Enjoy a selection of the best streaming apps")

    @property
    def grid(self):
        return stbt.Grid(stbt.Region(450, 334, 1215, 552), cols=4, rows=2)

    @property
    def home_menu(self):
        from ..homemenu import HomeMenu
        return HomeMenu(frame=self._frame)

    @property
    def selection(self):
        if self.home_menu.selection:
            return self.home_menu.selection.region

    def move_one(self, key):
        page = self.home_menu.move_one(key)
        specific = StreamingMenu(
            frame=page._frame)  # pylint: disable=protected-access
        if specific:
            return specific
        else:
            return page
