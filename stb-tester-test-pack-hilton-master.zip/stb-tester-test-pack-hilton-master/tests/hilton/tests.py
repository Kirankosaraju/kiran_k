from __future__ import print_function

import random
import time

import stbt

from .pages.homemenu import HomeMenu
from .pages.livetvmenu import LiveTvMenu
from .pages.streamingmenu import StreamingMenu


def test_watch_tv():
    page = LiveTvMenu.launch()
    timings = page.launch_tv()
    start = timings[0][0]
    for t, event, _ in timings:
        print(t - start, event)


def test_show_stay_info():
    page = HomeMenu.launch()
    page.navigate_to(selection_text="STAY INFO")


def test_launch_random_app():
    page = StreamingMenu.launch()
    for _ in range(random.randint(1, 4)):
        page = page.move_one("KEY_RIGHT")
    stbt.press("KEY_OK")
    time.sleep(10)
