This directory contains new APIs written by Stb-tester.com Ltd, that aren't
available yet in an official Stb-tester release. See the docstrings to
understand *what* each function does, and don't worry if you don't understand
the implementation (*how* it does it). Try not to modify this code directly.
