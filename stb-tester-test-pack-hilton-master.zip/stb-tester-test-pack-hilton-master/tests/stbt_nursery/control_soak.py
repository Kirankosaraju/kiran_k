# Copyright 2019 Stb-tester.com Ltd.

from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
from builtins import *  # pylint:disable=redefined-builtin,unused-wildcard-import,wildcard-import,wrong-import-order

import numpy
import stbt


def soak_remote_control(
        key_next="KEY_RIGHT", key_prev="KEY_LEFT", mask=None, count=100):
    """
    Soaks a remote control by pressing KEY_LEFT and KEY_RIGHT keys and making
    sure they have an effect each time.  We check that every time we press
    KEY_LEFT and KEY_RIGHT we get back to where we started.  This should be
    sufficient to detect missed keypresses and intermittent double presses.

    Use mask to exclude parts of the page that might change from press to
    press, such as picture-in-picture video or clocks.
    """
    if mask is None:
        m = numpy.ones((720, 1280, 3), dtype=numpy.uint8) * 255
    else:
        m = stbt.load_image(mask)

    # Get in a position where we'll be able to press left later. Note: no
    # assertion - it's ok if we can't move right right now
    stbt.press(key_next)
    stbt.press_and_wait(key_next, mask=m)  # pylint:disable=stbt-unused-return-value

    # Grab reference images of the left and right position. We need these to
    # check that we've actually moved, and haven't moved too far. We add an
    # alpha channel (transparency) using the user-supplied mask.
    right_template = numpy.append(stbt.get_frame(), m[:, :, :1], axis=2)

    if not stbt.press_and_wait(key_prev, mask=m):
        raise RuntimeError(
            "No movement after pressing %r during setup" % (key_prev,))
    if stbt.match(right_template):
        raise RuntimeError(
            "Setup error: No detectable differences after pressing %r"
            % (key_prev,))
    left_template = numpy.append(stbt.get_frame(), m[:, :, :1], axis=2)

    # Now we perform the actual test:
    for _ in range(count // 2):
        assert stbt.press_and_wait(key_next, mask=m)
        assert stbt.match(right_template)
        assert stbt.press_and_wait(key_prev, mask=m)
        assert stbt.match(left_template)
