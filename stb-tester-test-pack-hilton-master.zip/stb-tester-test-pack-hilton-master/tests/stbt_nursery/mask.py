# Copyright 2020 Stb-tester.com Ltd.

import numpy
from _stbt.types import Region


def mask_out(x, *args, **kwargs):
    return to_ndarray_mask(x, *args, invert=True, **kwargs)


def to_ndarray_mask(x, region=Region(0, 0, 1280, 720), dtype=numpy.uint8,
                    color_dims=3, invert=False):
    """Creates an ndarray mask from a stbt.Region"""
    out_val = 0
    if dtype == numpy.uint8:
        in_val = 255
    else:
        in_val = 1

    if invert:
        out_val, in_val = in_val, out_val

    shape = (region.height, region.width)
    if color_dims is not None:
        shape += (color_dims,)

    if isinstance(x, Region):
        out = numpy.full(shape, out_val, dtype=dtype)
        r = Region.intersect(x, region).translate(-region.x, -region.y)
        if r:
            out[r.y:r.bottom, r.x:r.right] = in_val
    else:
        raise TypeError("to_mask not implemented for type %s" % (type(x)))

    return out
