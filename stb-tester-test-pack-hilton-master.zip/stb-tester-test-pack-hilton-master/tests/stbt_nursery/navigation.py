# Copyright 2018-2020 Stb-tester.com Ltd.

from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
from builtins import *  # pylint:disable=redefined-builtin,unused-wildcard-import,wildcard-import,wrong-import-order

import random

import stbt
from _stbt.types import Region


def _as_region(obj):
    if isinstance(obj, Region):
        return obj
    try:
        return obj.selection.region
    except AttributeError:
        pass
    try:
        if isinstance(obj.selection, Region):
            return obj.selection
    except AttributeError:
        pass
    return obj.region


class NavigationFailed(AssertionError):
    def __init__(self, page, initial_region, to_region, current_region,
                 key_choices):
        super(NavigationFailed, self).__init__(self, "Navigation Failed")
        self.page = page
        self.initial_region = initial_region
        self.to_region = to_region
        self.current_region = current_region
        self.key_choices = key_choices

    def __str__(self):
        return ("Navigation failed: Attempted to get to %r from %r but "
                "pressing keys %r had no effect once selection reached "
                "position %r") % (
            self.to_region, self.initial_region, self.key_choices,
            self.current_region)


def navigate_fixed_layout(page, to_region):
    """Used to navigate menus where the selection moves on the page, but the
    page itself doesn't scroll.  This means the item you're navigating to
    doesn't move in response to pressing the direction keys.

    This function will use keys 'KEY_UP', 'KEY_DOWN', 'KEY_LEFT' and 'KEY_RIGHT'
    as appropriate depending on the relative location of `page.selection.region`
    and `to_region`.

    Limitations:

    * This function uses `press_and_wait()` for navigating so is not suitable
      for screens with animation including screens with picture-in-picture and
      live-tv behind transparency.

    Example use:

    This is a method within a `FrameObject` to select the button marked TV:

        def select_tv(self)
            return navigate_fixed_layout(
                self, stbt.match_text("TV", frame=self._frame))

    :param FrameObject page: The current frame object.
    :param Region to_region: The location to navigate to.

    :returns: The FrameObject corresponding to navigation being complete.  This
        may be the same object passed in as `page` if the `to_region` is already
        selected.  Typically this will be of the same type as `page` depending
        on the implementation of `page.refresh()`.
    :rtype: FrameObject
    """
    destination = _as_region(to_region)
    current = initial_region = _as_region(page)

    while True:
        current = _as_region(page)
        if Region.intersect(destination, current):
            return page
        keys = set()
        if destination.right < current.x:
            keys.add('KEY_LEFT')
        elif current.right < destination.x:
            keys.add('KEY_RIGHT')
        if destination.bottom < current.y:
            keys.add('KEY_UP')
        elif current.bottom < destination.y:
            keys.add('KEY_DOWN')

        key_choices = tuple(keys)
        t = None
        while keys:
            key = random.choice(keys)
            keys.remove(key)
            t = stbt.press_and_wait(key)
            if t:
                break
        else:
            raise NavigationFailed(page, initial_region, to_region,
                                   current, key_choices)

        page = page.refresh(t.frame)
        assert page, (
            "navigate_fixed_layout: Invalid Page %r for frame at time %f after "
            "pressing key %r" % (page, t.frame.time, key))


class EndOfList(Exception):
    """Raised from move_one when attempting to move the selection beyond the
    end of the data"""
    pass


class Movable(object):
    def move_one(self, key):
        raise NotImplementedError()


class NoSuchItem(Exception):
    pass


class _AttributeMatcher(object):
    # This exists so we get a nice __str__
    def __init__(self, keys):
        self._keys = keys

    def __call__(self, page):
        for k, v in self._keys.items():
            a = getattr(page, k)
            if a != v:
                stbt.draw_text("page.%s == %r.  Looking for %r: No match" % (
                    k, a, v))
                return False
        stbt.draw_text("Matched %s" % (self,))
        return True

    def __str__(self):
        return " and ".join(
            "page.%s == %r" % (k, v) for k, v in self._keys.items())

    def key(self, page):
        return tuple(getattr(page, k) for k in self._keys)

    def pages_equal(self, a, b):
        return self.key(a) == self.key(b)


class MenuMixin(Movable):
    """
    Inherit from this to add navigation to your menu FrameObject.

    Implements the method `select()` which can be used to select a given item
    in the menu.  Example:

        class MyPageObject(stbt.FrameObject, VerticalMenuMixin):
            @property
            def is_visible(self):
                ...

            @property
            def title(self):
                return stbt.ocr(frame=self._frame, region=...)

        page = MyPageObject()
        page = page.select(title="Bad Boys II")

    For vertical and horizontal menus use VerticalMenuMixin or
    HorizontalMenuMixin instead.

    Applicability: This works for 1-D menus that either wrap or block.

    Customisation: Override `move_one`, `region` and `menu_direction` in the
    subclass to customise behaviour.
    """
    # Can be overridden in subclasses:
    menu_direction = "KEY_DOWN"

    def navigate_to(self, **kwargs):
        """
        Move the selection until we find a page that matches the arguments.  For
        example: if you have a FrameObject with a property `title` you can call
        `page.select(title="Top Gun")`.

        Caveat: This will only work properly if the item you're searching for
        is unique.  Otherwise it may think the menu has wrapped.

        :return: The new page object

        :raises NoSuchItem: if the item cannot be found in the list.
        """
        is_match = _AttributeMatcher(kwargs)
        direction = self.menu_direction
        return _select(self, direction, is_match, is_match.pages_equal)

    def move_one(self, key):
        """Move a single step in a given direction.  By default we use
        `stbt.press_and_wait(..., region=self.region)`.

        For transparent UIs where `press_and_wait` doesn't give good results you
        can override this method.

        :type direction: str
        :param direction: The direction in which to move.  This will be a key
            name like 'KEY_DOWN'

        :rtype: stbt.FrameObject
        :return: A new page object for the new view

        :raises EndOfList: When we can't move in this direction because we've
            reached the end of the list.
        """
        # May be overridden by subclasses.  By default we use press_and_wait
        region = getattr(self, "region", Region.ALL)
        if stbt.press_and_wait(key, region=region):
            return self.refresh()
        else:
            raise EndOfList()


class VerticalMenuMixin(MenuMixin):
    menu_direction = "KEY_DOWN"


class HorizontalMenuMixin(MenuMixin):
    menu_direction = "KEY_RIGHT"


def _select(page, direction, is_target, is_identical):
    """
    Navigate through a 1D menu attempting to find a target. Deals with wrapping
    menus and menus where you get stuck at the end.

    :type page: Movable
    :param page: page

    :type direction: str
    :param direction: Direction to move in.  This is a key name.  For vertical
        menus this should be 'KEY_DOWN', for horizontal this should be
        'KEY_RIGHT'.

    :type is_target: Callable[[FrameObject], bool]
    :param is_target: A function taking a page and returning True if this is the
        target page and False otherwise.

    :type is_identical: Callable[[FrameObject, FrameObject], bool]
    :param is_identical: Compare two pages for equality.  This is used to detect
        menus wrapping.
    """
    first = page
    n = 0
    while True:
        assert page
        if is_target(page):
            return page
        try:
            page = page.move_one(direction)
        except EndOfList:
            stbt.draw_text(
                "Reached end of menu without seeing %s, trying other "
                "direction" % (is_target,))
            break
        if is_identical(page, first):
            raise NoSuchItem(
                "Couldn't find target %s in menu.  Wrapped around to the "
                "beginning" % (is_target,))

        n += 1

    backwards = repeat(direction, -1)[0]
    for _ in range(n):
        page = page.move_one(backwards)  # pylint: disable=protected-access
        assert page

    # Now we're back where we started
    if not is_identical(first, page):
        raise Exception("Expected to be back on first page.  Current page: %r, "
                        "expected %r" % (page, first))

    while True:
        try:
            page = page.move_one(backwards)
            assert page
        except EndOfList:
            stbt.draw_text("Item %s not found in list" % (is_target,))
            raise NoSuchItem("Couldn't find target %s in menu." % (is_target,))
        if is_target(page):
            return page


def repeat(key, n):
    if n >= 0:
        return [key] * n
    else:
        return [MAP_OPPOSITES[key]] * -n


OPPOSITES = [
    ("KEY_UP", "KEY_DOWN"),
    ("KEY_LEFT", "KEY_RIGHT"),
    ("KEY_VOLUMEUP", "KEY_VOLUMEDOWN"),
    ("KEY_FASTFORWARD", "KEY_REWIND"),
    ("KEY_PREVIOUS", "KEY_NEXT"),

    # What is next and what is previous with this is context dependent.  When
    # we're on an EPG typically CHANNELDOWN is next, while when watching live TV
    # CHANNELUP will be next
    ("KEY_CHANNELUP", "KEY_CHANNELDOWN"),
]
MAP_OPPOSITES = dict(OPPOSITES + [(_y, _x) for _x, _y in OPPOSITES])
